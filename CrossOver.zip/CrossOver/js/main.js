$(document).ready(function(){
	resizeDiv();

	
	$('.menu').find('li:eq(0)').addClass('itemselected');
	
		$('.content').html(Pages.home);
	$('.menu a').click(function(){
		$('.menu li').removeClass('itemselected');
		$(this).parent('li').addClass('itemselected');
		
	
	} );
	
	$('#setting').click( function(){
		$('.content').html(Pages.setting);
	} );
	
	$('#home').click( function(){
		$('.content').html(Pages.home);
	} );
	
		$('#dashboard').click( function(){
		$('.content').html(Pages.Dashboard);
		redrawChartDashboard();
	} );
	
	
		$('#scan').click( function(){
		$('.content').html(Pages.ScanResult);
	} );
	
	
});
var	Pages = {
	home :'<div class="col-md-12 animated fadeIn"> \
	     <div class="col-md-8 centerAlign mainContent"> \
			 <i class="fa fa-check-circle-o"></i> \
			 <h2 class="green">Your system is secure! You are protected!</h2> \
		 </div> \
		 <div class="col-md-4"> \
		   <div class="col-md-12 card"> \
		           <p>Last Update  : <span>Yesterday</span><i class="fa fa-refresh" aria-hidden="true"></i> \
 </p> \
		   </div> \
		      <div class="col-md-12  card"> \
		       <p>Last scan : <span>2:54 PM, Today</span><i class="fa fa-search" aria-hidden="true"></i> \
</p> \
		   </div> \
		      <div class="col-md-12 card"> \
		        <p>System status : <span class="sucesfull">Clean</span><i class="fa fa-bar-chart" aria-hidden="true"></i> \
</p> \
		   </div> \
		      <div class="col-md-12 card"> \
		        <p>Last actions : <span class="alarm">Malware Torjan 003 </span><i class="fa fa-wrench" aria-hidden="true"></i> \
</p> \
		   </div> \
		 </div> \
	  </div>',
	setting :"this is setting",
	Dashboard :"<div id='charts' class='card' style='height:400px; width:90%;margin: 20px auto;'></div>",
	ScanResult : "this is scan" 
}	

function resizeDiv(){
	var windowHeight = $( window ).height() ;
	windowHeight -= 122;
	$('.menu').css({'height': windowHeight + 'px'});
}	

// Get the CSV and create the chart
function  redrawChartDashboard(){
	$.getJSON('https://www.highcharts.com/samples/data/jsonp.php?filename=analytics.csv&callback=?', function (csv) {

    Highcharts.chart('charts', {

        data: {
            csv: csv
        },

        title: {
            text: 'Number of the trends founds recently'
        },

        subtitle: {
            text: 'Source: Venom Shield'
        },

        xAxis: {
            tickInterval: 7 * 24 * 3600 * 1000, // one week
            tickWidth: 0,
            gridLineWidth: 1,
            labels: {
                align: 'left',
                x: 3,
                y: -3
            }
        },
        	colors: ['#f99f1c', '#81d4f7'],
        yAxis: [{ // left y axis
            title: {
                text: null
            },
            labels: {
                align: 'left',
                x: 3,
                y: 16,
                format: '{value:.,0f}'
            },
            showFirstLabel: false
        }, { // right y axis
            linkedTo: 0,
            gridLineWidth: 0,
            opposite: true,
            title: {
                text: null
            },
            labels: {
                align: 'right',
                x: -3,
                y: 16,
                format: '{value:.,0f}'
            },
            showFirstLabel: false
        }],

        legend: {
            align: 'left',
            verticalAlign: 'top',
            y: 20,
            floating: true,
            borderWidth: 0
        },

        tooltip: {
            shared: true,
            crosshairs: true
        },

        plotOptions: {
            series: {
                cursor: 'pointer',
                point: {
                    events: {
                        click: function (e) {
                            hs.htmlExpand(null, {
                                pageOrigin: {
                                    x: e.pageX || e.clientX,
                                    y: e.pageY || e.clientY
                                },
                                headingText: this.series.name,
                                maincontentText: Highcharts.dateFormat('%A, %b %e, %Y', this.x) + ':<br/> ' +
                                    this.y + ' Risks',
                                width: 200
                            });
                        }
                    }
                },
                marker: {
                    lineWidth: 1
                }
            }
        },

        series: [{
            name: 'Hight risks',
            lineWidth: 4,
            marker: {
                radius: 4
            }
        }, {
            name: 'Risks'
        }]
    });
});
}

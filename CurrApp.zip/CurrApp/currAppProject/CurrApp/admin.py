# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin
from CurrApp.models import Curriculum, Curriculum2
# Register your models here.
admin.site.register(Curriculum)
admin.site.register(Curriculum2)
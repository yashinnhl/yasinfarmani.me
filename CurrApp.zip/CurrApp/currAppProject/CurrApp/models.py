# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

# Create your models here.
class Curriculum(models.Model):
    courseId = models.CharField(max_length = 264, unique = True)
    courseName = models.CharField(max_length = 264, unique = False)
    courseTOD = models.CharField(max_length = 264, unique = False)
    courseDuration = models.CharField(max_length = 30, unique = False)
    courseDescription = models.CharField(max_length = 20000, unique = False)
	
    def __str__(self):
             return self.courseId

			 
class Curriculum2(models.Model):
    courseId = models.CharField(max_length = 264, unique = True)
    courseName = models.CharField(max_length = 264, unique = False)
    courseTOD = models.CharField(max_length = 264, unique = False)
    courseDuration = models.CharField(max_length = 30, unique = False)
    courseDescription = models.CharField(max_length = 20000, unique = False)
	
    def __str__(self):
             return self.courseId
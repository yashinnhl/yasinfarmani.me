# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.db import models
import json
import datetime
from django.http import Http404, HttpResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.csrf import ensure_csrf_cookie
from django.core.files.storage import FileSystemStorage
import openpyxl
from openpyxl import load_workbook


# Create your modes here.
class Curriculum(models.Model):
    courseId = models.CharField(max_length = 264, unique = False,  null=True)
    courseName = models.CharField(max_length = 264, unique = False,  null=True)
    courseTOD = models.CharField(max_length = 264, unique = False,  null=True)
    courseDuration = models.CharField(max_length = 30, unique = False,  null=True)
    courseDescription = models.CharField(max_length = 20000, unique = False, null=True)
	
    def __str__(self):
              return self.courseId

			 
class Curriculum2(models.Model):
    courseId = models.CharField(max_length = 264, unique = False, null=True)
    courseName = models.CharField(max_length = 264, unique = False, null=True)
    courseTOD = models.CharField(max_length = 264, unique = False, null=True)
    courseDuration = models.CharField(max_length = 30, unique = False, null=True)
    courseDescription = models.CharField(max_length = 20000, unique = False, null=True)
	
    def __str__(self):
             return self.courseId

			 
#-------------------------------------------------- request to read file ------------------------------------
@ensure_csrf_cookie			 
def submitFrm(request):
    if request.is_ajax() and request.POST:
        data= request.body
        print('form submitted')
        #print('Row:'+ str(row_count) +"-------- Col:" + str(column_count) ) 
        bindData()				
        return HttpResponse(json.dumps(data), content_type='application/json')
    else:
        raise Http404
		
def bindData():
	wb = load_workbook(filename = 'static/data/NCPI-EI-II.xlsx')
	ws = wb.worksheets[0]
	row_count = ws.max_row
	column_count = ws.max_column
	for i in range(1,row_count+1):
				   #for j in range(1,column_count+1):
				    #if ws.cell(row=i, column=j).value is not None:
					#string1 = str(ws.cell(row=i, column=j).value)
					#string = ' '.join(string.split())
					#print( string )
					Curriculum.objects.create(courseId = ws.cell(row=i, column=1).value,courseName = ws.cell(row=i, column=2).value, courseTOD = ws.cell(row=i, column=3).value, courseDuration = ws.cell(row=i, column=4).value, courseDescription = ws.cell(row=i, column=5).value)
					print('-----------------------------------------------------------------------')
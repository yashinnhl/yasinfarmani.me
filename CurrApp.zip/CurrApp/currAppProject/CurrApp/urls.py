from django.conf.urls import url
from CurrApp import views

app_name = 'CurrApp'
urlpatterns = [
    url(r'^$',views.index, name='index'),
	
]
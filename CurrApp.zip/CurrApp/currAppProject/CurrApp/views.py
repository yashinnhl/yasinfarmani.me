# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
from django.http import HttpResponse
from .models import Curriculum, Curriculum2
from django.forms.models import model_to_dict
# Create your views here.


def index(request):
    curriculums = Curriculum.objects.filter()
    curriculums2 = Curriculum2.objects.filter()
    return render(request,'CurrApp/index.html',{'access_records': curriculums, 'access_records2' : curriculums2 })

import SimpleHTTPServer
import SocketServer
import json
from pprint import pprint
import requests
import urllib2


PORT = 8000

Handler = SimpleHTTPServer.SimpleHTTPRequestHandler

httpd = SocketServer.TCPServer(("", PORT), Handler)

print "serving at port", PORT

#with open('public/json/data.json') as data_file:    
 #   data = json.load(data_file)

#pprint(data)

# req = urllib2.Request('http://allhero', data)
# req.add_header('Content-Type', 'application/json')

# response = urllib2.urlopen(req, json.dumps(data))

httpd.serve_forever()
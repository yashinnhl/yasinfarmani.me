# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.
def index(request):
   #return HttpResponse("Hello World!") 
    my_dict = {'insert_me' : "Hello I am from views.py !"}
    return render(request,'SaitamaApp2/index.html', context=my_dict)

def preview(request):
   #return HttpResponse("Hello World!") 
    Prev_dict = {'insert_prev' : "Hello I am from views.py !"}
    return render(request,'SaitamaApp2/preview.html', context=Prev_dict)

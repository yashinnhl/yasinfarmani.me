 var text;
 var currentElement
 $(function(){
     
    $(document).on('click change keyup','.item', function(ev){
		$(this).addClass('selectedItems').removeClass('editItems');
	});  
	//#####################################################  Click edit text #########################################
 	 $(document).on('dblclick','.item', function(ev){
		 
		  currentElement =  $(this);
		    if(ev.target.getAttribute('data-category') == 'text'){
			    $('.textProperty').hide();   
                text = $(this).text();				
				$(this).html("<textarea class='editarea' id='textarea'>"+ text +"</textarea>");
				$('.editarea').select();
		   }
		    if(ev.target.getAttribute('data-category') == 'box'){
			   alert('this is box');
		   }
	 });
     	 $(document).on('dblclick','.Inisdeitem', function(ev){ 
		 currentElement =  $(this);
		     ev.stopPropagation();
			  $('.textProperty').hide();   
                text = $(this).text();				
				$(this).html("<textarea class='editarea' id='textarea'>"+ text +"</textarea>");
				$('.editarea').select();
		 });
	 	  $(document).on('click', function(){
			  $(currentElement).html( $('.editarea').val());
			    text = '';
			   currentElement = '';
		  });
		  $('.slides','#slide_viewer','#right_menu').click( function(){
			    $(currentElement).html( $('.editarea').val());
			    text = '';
			   currentElement = '';
		  });
		  	$('#right_menu').click(function(ev){
				ev.stopPropagation();
				$(currentElement).html( $('.editarea').val());
			    text = '';
			   currentElement = '';
			});
		//########################################    Drag add and sort rows , items      ############################################	
	  $(document).on('click','.row', function(ev){
		  ev.stopPropagation();
		$(this).addClass('selectedRow');    
	  });
	 	 //************************************* Make items draggable ***********************************************
	 $('#title , #subTitle , #subTitle2, #subTitle3 , #bodyText , #imageOrdinary , #gridCol12 , #gridCol66 , #gridCol444 , #Jumbotron , #NoteBox, #KeyConceptsBox, #ImportantBox, #ActivityBox , #TestBox, #GoToBox, #CalculationBox').draggable({
		 helper:'clone',
		 appendTo: '.slide',
		 start: function( event, ui ) {
			 colDroppable(); 	  
		 },
	 });
	  //************************************* Make .slide or slideviewr sortable ***********************************************
    $('.slide').sortable({
		 items: ".row, li",
		 placeholder: "ui-state-highlight",
		 revert: '100',
		 sort:function(event, ui){
			 $('.row').css('opacity','0.5');
		 },
		 stop:function(event, ui){
			 $('.row').css('opacity','1');
		 },
		 over: function( event, ui ) {
				 var yourCurrentlyHoveredElement = $(this); //the 'this' under over event
				 alert(yourCurrentlyHoveredElement);
		 }
	 });
	 $(".slide").disableSelection();
	 //************************************* Slide can only accept col  ***********************************************
	 $('.slide').droppable({
		    
			drop:function(event, ui) {
             if(ui.draggable.prop('id') == 'gridCol12')	{
				  $(this).append("<div  class='row'><div class='col-md-12 col'></div></div>");
				  // $('.slide').append("<div  class='row'><div class='col-md-12 col'></div></div>");
				   $(this).find('.emptylayout').remove();
				   colDroppable()
			 }	
             if(ui.draggable.prop('id') == 'gridCol66')	{
				   $('.slide').append("<div  class='row'><div class='col-md-6 col'></div><div class='col-md-6 col'></div></div>");
				   $(this).find('.emptylayout').remove();
				  colDroppable()
			 }	
              if(ui.draggable.prop('id') == 'gridCol444'){
				   $('.slide').append("<div  class='row'><div class='col-md-4 col'></div><div class='col-md-4 col'></div><div class='col-md-4 col'></div></div>");
				   $(this).find('.emptylayout').remove();
				  colDroppable()
			 }	              			 
			},	
      });
	   //************************************* Different items append to slide  ***********************************************
	  function colDroppable(ev){
			  $('.col').droppable({
		  drop: function(event, ui){
			  	if(ui.draggable.prop('id') == 'title'){
				   $(this).append("<h1 class='item' data-type='text' data-category='text'>This is title</h1>");
			    }
			if(ui.draggable.prop('id') == 'subTitle'){
				   $(this).append("<h2 class='item' data-type='text' data-category='text'>This is sub title</h2>");
			    }
			if(ui.draggable.prop('id') == 'subTitle2'){
				   $(this).append("<h3 class='item' data-type='text' data-category='text'>This is sub title 3</h3>");
			   }
			if(ui.draggable.prop('id') == 'subTitle3'){
				   $(this).append("<h4 class='item' data-type='text' data-category='text'>This is sub title 4</h4>");
			   }
			if(ui.draggable.prop('id') == 'bodyText'){
				   $(this).append("<p class='item' data-type='text' data-category='text'>This is body text</p>");
			   }   
			 if(ui.draggable.prop('id') == 'imageOrdinary'){
				   $(this).append("<img alt='cat' class='item img-responsive' src='../static/images/cat.jpg' data-type='image' data-category='img' >");
			   }
              if(ui.draggable.prop('id') == 'Jumbotron'){
				   $(this).append("<div class='item jumbotron'><h1 class='Inisdeitem'>Your Title Here</h1><p class='Inisdeitem'>You can write the Jumbotron paragraph here!</p></div>");
			   } 
			 if(ui.draggable.prop('id') == 'NoteBox' ){
				 $(this).append("<div class='media item notebox' data-category='box'><div class='media-left'><i class='fa fa-lightbulb-o fa-4x'></i></div><div class='media-body'><h4 class='media-heading Inisdeitem' >Heading</h4><span class='Inisdeitem'>Your content goes here</span></div></div>");
			  }
			   if(ui.draggable.prop('id') == 'KeyConceptsBox'){
				 $(this).append("<div class='media item keyconceptbox' data-category='box'><div class='media-left'> <i class='fa fa-key fa-4x' ></i></div><div class='media-body'><h4 class='media-heading Inisdeitem'>Heading</h4><span class='Inisdeitem'> Your content goes here </span></div></div>");
			  }	 
			 if(ui.draggable.prop('id') == 'ImportantBox'){
				$(this).append("<div class='media item importantbox' data-category='box'><div class='media-left'><i class='fa fa-exclamation-triangle fa-4x' aria-hidden='true' ></i></div><div class='media-body'><h4 class='media-heading Inisdeitem'>Heading</h4><span class='Inisdeitem'>Your content goes here</span></div></div>");
				}
              	 if(ui.draggable.prop('id') == 'ActivityBox'){
				   $(this).append("<div class='media item activitybox' data-category='box'><div class='media-left'><i class='fa fa-flag fa-4x' aria-hidden='true' ></i></div><div class='media-body'><h4 class='media-heading Inisdeitem'>Heading</h4><span class='Inisdeitem'>Your content goes here</span></div></div>");
				}
               	 if(ui.draggable.prop('id') == 'TestBox'){
				   $(this).append("<div class='media item testbox' data-category='box'><div class='media-left'><i class='fa fa-pencil-square-o fa-4x' aria-hidden='true' ></i></div><div class='media-body'><h4 class='media-heading Inisdeitem'>Heading</h4><span class='Inisdeitem'>Your content goes here</span></div></div>");
				}
				 if(ui.draggable.prop('id') == 'GoToBox'){
				   $(this).append("<div class='media item gotobox' data-category='box'><div class='media-left'><span class='glyphicon glyphicon-share-alt' aria-hidden='true' ></span></i></div><div class='media-body'><h4 class='media-heading Inisdeitem'>Heading</h4><span class='Inisdeitem'>Your content goes here</span></div></div>");
				}
				if(ui.draggable.prop('id') == 'CalculationBox'){
				   $(this).append("<div class='media item calculationbox' data-category='box'><div class='media-left'><i class='fa fa-calculator fa-4x' aria-hidden='true' ></i></div><div class='media-body'><h4 class='media-heading Inisdeitem'>Heading</h4><span class='Inisdeitem'>Your content goes here</span></div></div>");
				}
				unsave();
		  },
		  hoverClass: "drop-hover"
	  }); 

	  }
	
			
							
      //######################################################## toolbox Menu Manager ###########################################################################################

	 $('#showHideGrid').click(function(){
		 if($(this).text() == 'Show Layout'){
			$('.col').css('border','1px dashed #ddd'); 
			$(this).text('Hide Layout');
		 }else{
			$('.col').css('border','1px dashed transparent');
		    $(this).text('Show Layout'); 
		 } 		 
	 }); 
	$('#toolbar  i').click(function(ev){
		  ev.stopPropagation();
		  var id = ev.target.id;
		  $('#toolbar  i').removeClass('toolbarSelect');
		  $(this).addClass('toolbarSelect');
		  $('.menu').hide();
		  if(id == 'textTools'){
			   $(".text-box").show();
		  }else if(id == 'imgTools'){
			 $(".image-box").show(); 
		  }else if(id == 'grdTools'){
			  $(".grid-box").show(); 
		  }else if(id == 'jmbTools'){
			  $(".jmb-box").show();
		  }
	 });
	 $(".text-box, .grid-box ,.image-box ,.jmb-box").click(function(ev){
		  ev.stopPropagation();
	 } );
	 //##################################################################### document events ########################################################################################
	  $(document).click(function(){
		$(".text-box , .image-box , .grid-box ,.jmb-box").hide();   
	 });
	  $('.slide,body').click(function(){
		$('.item').removeClass('selectedItems editItems');
		$('.row').removeClass('selectedRow'); 
		$('#toolbar  i').removeClass('toolbarSelect');
	 });
	  $(document).click(function(){
		     $('#leftAlign , #centreAlign , #rightAlign ').removeClass('PropertybtnActive');
			 $('.textProperty').hide();  

	   });
	   //############################################################### Text Property clicks ##############################################################
	    $(document).on('click', '.item' ,function(ev){
		   ev.stopPropagation();
		   //alert(ev.target.getAttribute('data-category'));
		   if(ev.target.getAttribute('data-category') == 'text'){
			    $('.textProperty').show();   
		   }else{
			    $('.textProperty').hide(); 
		   }
		   $('#rightAlign, #leftAlign , #centreAlign').removeClass('PropertybtnActive');
		  if($('.selectedItems').hasClass('rightAlign')){
								$('#rightAlign').addClass('PropertybtnActive');
				}else if($('.selectedItems').hasClass('leftAlign')){
								$('#leftAlign').addClass('PropertybtnActive');
				}else if($('.selectedItems').hasClass('centreAlign')){
								$('#centreAlign').addClass('PropertybtnActive');
				} 
				
	   }); 
	   $('#leftAlign').click(function(){
		    $(this).addClass('PropertybtnActive');
			$('#centreAlign , #rightAlign').removeClass('PropertybtnActive');
		    $('.selectedItems').addClass('leftAlign').removeClass('rightAlign centreAlign');
			
	   });
	    $('#centreAlign').click(function(){
			 $(this).addClass('PropertybtnActive');
			$('#leftAlign , #rightAlign').removeClass('PropertybtnActive');
		   $('.selectedItems').addClass('centreAlign').removeClass('rightAlign leftAlign');
		  
	   });
	    $('#rightAlign').click(function(){
			 $(this).addClass('PropertybtnActive');
			$('#leftAlign , #centreAlign').removeClass('PropertybtnActive');
		   $('.selectedItems').addClass('rightAlign').removeClass('leftAlign centreAlign');
		   
	   });
		$("#font_list").change(function(ev)
			{
				ev.stopPropagation();
			   var x = $(this).val();
				if(x==1) 
					$('.selectedItems').addClass('x_Small_font').removeClass('small_font medium_font large_font xLarge_font'); 
				if(x==2) 
					$('.selectedItems').addClass('small_font').removeClass('x_Small_font medium_font large_font xLarge_font');
				if(x==3) 
					$('.selectedItems').addClass('medium_font').removeClass('small_font x_Small_font large_font xLarge_font');
                if(x==4) 
					$('.selectedItems').addClass('large_font').removeClass('small_font medium_font x_Small_font xLarge_font');				
		        if(x==5)
				   $('.selectedItems').addClass('xLarge_font').removeClass('small_font medium_font large_font x_Small_font');
			});
		
	   //################################################## Color Picker ##########################################################################
      
	      $('#btnColorPicker').click(function(){
			 // ev.stopPropagation();
					 $('#colors').html('');
					  var colorList = '';
					  colorList += '<ul class="ListColors">';
					  for(i=0;i<=7; i++){
						 colorList += '<li class="colorItem" ></li>';
					   }
					  colorList += '</ul>';
					  $('#colors').html(colorList);
					  $('#colors').toggle(); 
		  });
		  $('#colors').delegate('li','click',function() {
                var hexcolor  = $(this).css('backgroundColor');
				hexc(hexcolor);
				if(color == '#ff3838'){
					$('.selectedItems').addClass('red').removeClass('black blue yellow green orange gray purple');
				}else if(color == '#000000'){
					$('.selectedItems').addClass('black').removeClass('red blue yellow green orange gray purple');
				}
				else if(color == '#007ac8'){
					$('.selectedItems').addClass('blue').removeClass('red black yellow green orange gray purple');
				}
                else if(color == '#faff2b'){
					$('.selectedItems').addClass('yellow').removeClass('red black blue green orange gray purple');
				}
				else if(color == '#00953b'){
					$('.selectedItems').addClass('green').removeClass('red black blue yellow orange gray purple');
				}
				else if(color == '#e64900'){
					$('.selectedItems').addClass('orange').removeClass('red black blue yellow green gray purple');
				}
				else if(color == '#e64900'){
					$('.selectedItems').addClass('gray').removeClass('red black blue yellow green orange purple');
				}
				else if(color == '#fa1eff'){
					$('.selectedItems').addClass('purple').removeClass('red black blue yellow green orange gray');
				}
				
            });
			  
			
	  //################################################## Delete Items with click DEL ##################################################
	  $('html').keyup(function(e){
			if(e.keyCode == 46 && $('.item').hasClass("selectedItems")) {
				//alert('Delete key released');
				$(".selectedItems").remove();
			}
			if(e.keyCode == 46 && $('.row').hasClass("selectedRow")) {
				//alert('Delete key released');
				$(".selectedRow").remove();
				if ($('#slide_window').is(':empty')){
				  alert('is empty');
				     $("#slide_window").html("<h1 class='emptylayout'   readonly>Please add layout first</h1>");
				}
			}
	
		});

}); //end of document ready
//################################# change color code from rgb to hex #############################################################
 function hexc(colorval) {
    var parts = colorval.match(/^rgb\((\d+),\s*(\d+),\s*(\d+)\)$/);
    delete(parts[0]);
    for (var i = 1; i <= 3; ++i) {
        parts[i] = parseInt(parts[i]).toString(16);
        if (parts[i].length == 1) parts[i] = '0' + parts[i];
    }
    color = '#' + parts.join('');

    return color;
}
//############################################## SAVE any changes ##########################################################################################################################
function saving(){
	               
	      var  htmlContent  =  $('#slide_window').html();
		  var newHtml = htmlContent.replace(/"/g, "'");
		  newHtml = newHtml.replace(/(?:\r\n|\r|\n)/g, '');
		  myJob.mod[CurrSlide.mInex].slides[CurrSlide.sInex].content = newHtml;	
          unsave();
}



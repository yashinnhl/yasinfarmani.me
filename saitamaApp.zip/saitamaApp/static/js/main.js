	var dataType;
	var clickedObjectModule, MInedx, SIndex,PrevoiusSlide,nextSlide,NextModule,PrevoiusModule;
	var ViewerScroll;
$(function(){
	var data;
	$.ajaxSetup({ cache: false });
	//---------------------------------------------------------- get json data -------------------------------------------------
		$.ajax({
		  dataType: "json",
		  url:  "/static/data/coursedata2.json",
		  success: function(data){
			 $("#slide_window").append(data.mod[0].slides[0].content);
			 $("#SlideTitle").html(data.mod[0].slides[0].title);
			 $('#courseTitle').html(data.courseTitle);
			  for(var i=0;i<data.mod.length;i++){
				$("#slide_viewer").append('<div class="module" data-module="'+ i +'" data-type="module">'+ data.mod[i].modTitle +'</div><div class="module'+ i +'body "><div data-type="divider" class="divider"></div></div>');
                   for( var j=0;j<data.mod[i].slides.length;j++){
				  $('.module'+ i +'body').append('<div class="slides" data-type="slide" data-module-index="'+ i +'"  data-slide-index="'+ j +'">'+ data.mod[i].slides[j].title +'</div><div class="divider" data-type="divider"></div>'); 
				 }	  		  
			  }  
			 for(i=0;i<data.mod.length;i++){
				//alert(data.mod[i].modState); 
				if(data.mod[i].modState == 'close'){
					$('.module'+ i +'body').hide();
				}else if(data.mod[i].modState == 'open'){
					$('.module'+ i +'body').show();
				}
			 }
	//-------------------------------- click on slide to show content ----------------------------------------------------------
				$(document).on('click','.slides',function(ev){
				    var m  = $(this).attr('data-module-index');
					var s = $(this).attr('data-slide-index');
				   $("#slide_window").html(data.mod[m].slides[s].content);
				   $("#SlideTitle").html(data.mod[m].slides[s].title);
				});
	//----------------------------------left click menu ---------------------------------------------------------------------------
				 document.getElementById('slide_viewer').addEventListener('contextmenu', function(ev) { 
							ev.preventDefault();
							var mosPsoition = findCursorPosition(ev);
							dataType = ev.target.getAttribute("data-type");
							clickedObjectModule = ev.target.getAttribute("data-module");
							MInedx = ev.target.getAttribute("data-module-index");
							SIndex = ev.target.getAttribute("data-slide-index");
							PrevoiusSlide = $(ev.target).prev('.slides');
							nextSlide = $(ev.target).next('.slides');
							PrevoiusModule = $(ev.target).parent().prev('.module');
							NextModule = $(ev.target).parent().next('.module');
							console.log(dataType)
							showSlideMenu(mosPsoition.x,mosPsoition.y,dataType);
				 }, true);
	//----------------------------------------------click Rename Section ----------------------------------------------------------
	             $('#RenameSection').click(function(ev){
					 if(dataType == "module"){
						$('#slide_viewer').find("[data-module='"+ clickedObjectModule +"']").html("<input class='renameEditor' type='text' name='editor'><button id='admitRename' type='button'>ok</button>");
						$(document).on('click','#admitRename',function(ev){
							data.mod[clickedObjectModule].modTitle = $('.renameEditor').val();
							$.ajax({
								type: "POST",
								dataType: "json",
								url: "/ajax/saveData/",
								data: JSON.stringify(data),
								success: function(data){
								  $('#slide_viewer').find("[data-module='"+ clickedObjectModule +"']").html($('.renameEditor').val());
								},
								error: function(e){
									
								}
							});
						});
					 } 
				 });
		 
    //----------------------------------------------click Remove Section ----------------------------------------------------------
				$('#RemoveSection').click(function(ev){
					if(dataType == "module"){
					   data.mod.splice(clickedObjectModule,1); 
                       $.ajax({
								type: "POST",
								dataType: "json",
								url: "/ajax/saveData/",
								data: JSON.stringify(data),
								success: function(data){
								  //location.reload();
								   ViewerScroll = $('#slide_viewer').scrollTop();
								  $('#slide_viewer').html('');							
								  jsonReloading();								  
								},
								error: function(e){		
						        }
                      });						
					}
				});
	//----------------------------------------------click New Slide ---------------------------------------------------------------
                $('#addNewSlide').click(function(ev){
					
					if(dataType == "slide"){
						 data.mod[MInedx].slides.splice(SIndex+1,0,{"content": "<h1>This is title 33</h1>",
			            "title": "Slide 33", "mod": "0"});
						}
					if(dataType == "divider"){
					       var m = $(nextSlide).attr('data-module-index');	
					       var s = $(nextSlide).attr('data-slide-index');	
						   if(m != undefined && s != undefined){
								 data.mod[m].slides.splice(s,0,{"content": "<h1>This is title 33</h1>",
								"title": "Slide 33", "mod": "0"});
						    }
							if( m == undefined && s== undefined){
								  m = $(PrevoiusSlide).attr('data-module-index');	
					              s = $(PrevoiusSlide).attr('data-slide-index');
								data.mod[m].slides.splice(s+1,0,{"content": "<h1>This is title 33</h1>",
								"title": "Slide 33", "mod": "0"});
							}
						}
                              $.ajax({
								type: "POST",
								dataType: "json",
								url: "/ajax/saveData/",
								data: JSON.stringify(data),
								success: function(data){
								  //location.reload();
								   ViewerScroll = $('#slide_viewer').scrollTop();
								  $('#slide_viewer').html('');
								  jsonReloading();
								},
								error: function(e){		
						        }
                      });						
					 
				});	
	//---------------------------------------------Click Delete Slide ----------------------------------------------------------------------
	             $('#DeleteSlide').click(function(ev){
					if( data.mod[MInedx].slides.length == 1){
						alert("You can not delete this slide if you want you can remove section instead!");
					}
					if(dataType == "slide" && data.mod[MInedx].slides.length > 1){
						console.log(dataType+','+MInedx+','+SIndex + ',' + JSON.stringify(data.mod[MInedx].slides) );
						 data.mod[MInedx].slides.splice(SIndex,1);
                             $.ajax({
								type: "POST",
								dataType: "json",
								url: "/ajax/saveData/",
								data: JSON.stringify(data),
								success: function(data){
								  //location.reload();
								   ViewerScroll = $('#slide_viewer').scrollTop();
								  $('#slide_viewer').html('');
								  jsonReloading();
								},
								error: function(e){		
						        }
                      });						
					}
				});
		//---------------------------------------------Click Duplicate Slide ----------------------------------------------------------------------
	             $('#duplicateSlide').click(function(ev){
					
					if(dataType == "slide"){
							console.log(dataType+','+MInedx+','+SIndex + ',' + JSON.stringify(data.mod[MInedx].slides) );
								 data.mod[MInedx].slides.splice(SIndex+1,0,data.mod[MInedx].slides[SIndex]);
                             $.ajax({
								type: "POST",
								dataType: "json",
								url: "/ajax/saveData/",
								data: JSON.stringify(data),
								success: function(data){
								  //location.reload();
								 ViewerScroll = $('#slide_viewer').scrollTop();
								  $('#slide_viewer').html('');
								  jsonReloading();
								 
								},
								error: function(e){		
						        }
                      });						
					}
				});  				
       //--------------------------------------------- ----------addNewSection------------------------------------------------------------
						 $('#addNewSection').click(function(){
							if(dataType == "viewer"){
									data.mod.push({"slides": [{"content": "<h1>This is title 34</h1>","title": "Slide 34","mod": "11"}],"modTitle": "ThiisNew","modState": "open"});
							}
							if(dataType == "divider"){
								 var m = $(nextSlide).attr('data-module-index');	
					             var s = $(nextSlide).attr('data-slide-index');
								 if( m != undefined && s != undefined){
									 var slicedArray = data.mod[m].slides.splice(s);
									 //alert(JSON.stringify(slicedArray));
									 data.mod.splice(m,0,{"slides": slicedArray,"modTitle": "AddInsert","modState": "open"});
									 if(data.mod[m].slides.length > 0){
											
											// alert('it is greater than 0'); 
									}
									if(data.mod[m].slides.length == 0){
										 //alert('you can not add section to single slide please add new section'); 
										//data.mod[m].slides.push({"content": "<h1>This is title 34</h1>","title": "Slide 34","mod": "11"});
									}
									// alert(m +' - '+s); 
								 }
								 if(m == undefined && s == undefined){
									alert('undefined'); 
					/* 				 m = $(PrevoiusSlide).attr('data-module-index');	
					                 s = $(PrevoiusSlide).attr('data-slide-index');
									 data.mod.splice(m,0,{"slides": [{"content": "<h1>This is title 34</h1>","title": "Slide 35","mod": "11"}],"modTitle": "ThiisNew","modState": "open"}); */
								 }
								
							}
							 $.ajax({
										type: "POST",
										dataType: "json",
										url: "/ajax/saveData/",
										data: JSON.stringify(data),
										success: function(data){
										  //location.reload();
										 ViewerScroll = $('#slide_viewer').scrollTop();
										  $('#slide_viewer').html('');
										  jsonReloading();
										 
										},
										error: function(e){		
										}
							  }); 
						 });//end of click addd new section between slides and modules 
//------------------------------------------------------------------------------------Click Add Section----------------------------------------------------------------------------------------------		 
						 $('#addSection').click(function(ev){
								if(dataType == "slide"){
									//console.log(dataType+','+MInedx+','+SIndex + ',' + JSON.stringify(data.mod[MInedx].slides));
									if(data.mod[MInedx].slides.length == 1 || SIndex == 0){	
										alert("You can not add more section here!");
									}
									if(data.mod[MInedx].slides.length > 1 && SIndex != 0){
									   var slicedArray = data.mod[MInedx].slides.splice(SIndex);	
									  // alert(JSON.stringify(slicedArray))
									   data.mod.splice(MInedx,1,{"slides": slicedArray,"modTitle": "newSection","modState": "open"});
									}
							    }
							 	  $.ajax({
										type: "POST",
										dataType: "json",
										url: "/ajax/saveData/",
										data: JSON.stringify(data),
										success: function(data){
										  //location.reload();
										 ViewerScroll = $('#slide_viewer').scrollTop();
										  $('#slide_viewer').html('');
										  jsonReloading();
										 
										},
										error: function(e){		
										}
							  });   
						});  		

       //---------------------------------------------------------- slider slide animation ---------------------------------------
		$(document).on('click','.module',function(ev){
		   // console.log(ev.target.nextSibling.className);
		  var Mod = ev.target.getAttribute("data-module");
		    if(data.mod[Mod].modState == "close"){
				data.mod[Mod].modState = "open";
			}else if(data.mod[Mod].modState == "open"){
				data.mod[Mod].modState = "close";
			}
	     	   	 	  $.ajax({
										type: "POST",
										dataType: "json",
										url: "/ajax/saveData/",
										data: JSON.stringify(data),
										success: function(data){
										  //location.reload();
										  ViewerScroll = $('#slide_viewer').scrollTop();
										  $('#slide_viewer').html('');
										  jsonReloading();
										},
										error: function(e){		
										}
							  }); 
		 });						
	//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------		 
		 
		 }//end of reading json data
		});
	//--------------------------------------------Reload json without refreshing page ---------------------------------------------------

	function jsonReloading(){
				$.ajax({
			  dataType: "json",
			  url:  "/static/data/coursedata2.json",
			  success: function(data){
				 $("#slide_window").html(data.mod[0].slides[0].content);
				 $("#SlideTitle").html(data.mod[0].slides[0].title);
				 $('#courseTitle').html(data.courseTitle);
				  for(var i=0;i<data.mod.length;i++){
					$("#slide_viewer").append('<div class="module" data-module="'+ i +'" data-type="module">'+ data.mod[i].modTitle +'</div><div class="module'+ i +'body "><div data-type="divider" class="divider"></div></div>');
					   for( var j=0;j<data.mod[i].slides.length;j++){
					  $('.module'+ i +'body').append('<div class="slides" data-type="slide" data-module-index="'+ i +'"  data-slide-index="'+ j +'">'+ data.mod[i].slides[j].title +'</div><div class="divider" data-type="divider"></div>'); 
					 }	  		  
				  }
				  for(var i=0;i<data.mod.length;i++){
												//alert(data.mod[i].modState); 
												if(data.mod[i].modState == 'close'){
													$('.module'+ i +'body').hide();
												}else if(data.mod[i].modState == 'open'){
													$('.module'+ i +'body').show();
												}
											 } 
				  $('#slide_viewer').scrollTop(ViewerScroll);		  
			  }
			  
			});
			
	}

	//---------------------------------------------------------- Load json data -------------------------------------------------
	$('#Uploadfile').click(function(){
		
	
		
	});


});
//-------------------------------------------------------------left click customize menu --------------------------------------
function showSlideMenu(x,y,dType){
			document.getElementById('SlideMenu').style.top = y + 'px';
			document.getElementById('SlideMenu').style.left = x + 'px';
			customizeSlideMenu(dataType);
			$('#SlideMenu').show();
	}
function findCursorPosition(event){
			var currentMousePos = { x: -1, y: -1 };
			currentMousePos.x = event.clientX;
			currentMousePos.y = event.clientY;
			return currentMousePos;
	}
//Customizing data type menu based on its position and data type target
function customizeSlideMenu(dataType){

if(dataType == "slide"){
		$("#SlideMenu").find('li:eq(0),li:eq(1),li:eq(2),li:eq(3)').show();
	   $("#SlideMenu").find('li:eq(4),li:eq(5),li:eq(6)').hide();
 }else if (dataType == "module" ){
		$("#SlideMenu").find('li:eq(0),li:eq(1),li:eq(2),li:eq(3),li:eq(4)').hide();
		$("#SlideMenu").find('li:eq(5),li:eq(6)').show();
  }else if(dataType == "divider"){
		$("#SlideMenu").find('li:eq(1),li:eq(2),li:eq(3),li:eq(5),li:eq(6)').hide();
		$("#SlideMenu").find('li:eq(0),li:eq(4)').show();
    }
	else{
		$("#SlideMenu").find('li:eq(0),li:eq(1),li:eq(2),li:eq(3),li:eq(5),li:eq(6)').hide();
		$("#SlideMenu").find('li:eq(4)').show();
	}
}
$(document).click(function(){
 $("#SlideMenu").hide();
});
//------------------------------------------success function ------------------------------------------------------------------

//-------------------------------------------------------- Add cookie and crftoken for django forms ----------------------------
function getCookie(name) {
    var cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        var cookies = document.cookie.split(';');
        for (var i = 0; i < cookies.length; i++) {
            var cookie = jQuery.trim(cookies[i]);
            // Does this cookie string begin with the name we want?
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}
var csrftoken = getCookie('csrftoken');
function csrfSafeMethod(method) {
    // these HTTP methods do not require CSRF protection
    return (/^(GET|HEAD|OPTIONS|TRACE)$/.test(method));
}
$.ajaxSetup({
    beforeSend: function(xhr, settings) {
        if (!csrfSafeMethod(settings.type) && !this.crossDomain) {
            xhr.setRequestHeader("X-CSRFToken", csrftoken);
        }
    }
}); 
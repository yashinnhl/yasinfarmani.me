	var dataType;
	var clickedObjectModule, MInedx, SIndex,PrevoiusSlide,nextSlide,NextModule,PrevoiusModule;
	var ViewerScroll;
	var data;   //json data variable
	var myJob; //local storage variable
	var CurrSlide = { mInex : 0 , sInex : 0 };
	var editMode = false;
	sessionStorage.setItem('IndexSlide', 0);
$(function(){
 // alert(typeof(localStorage));
	$.ajaxSetup({ cache: false });
	//############################################## get json data and set local storage #################################################################################
		$.ajax({
		  dataType: "json",
		  url:  "/static/data/coursedata2.json",
		  success: function(data){
			      if(typeof(localStorage) != null){
						localStorage.setItem('myWork', JSON.stringify(data));
						 myJob = localStorage.getItem('myWork');
						myJob =    JSON.parse(myJob);
				   }else{
						alert('This browser does not support local storage!!!')
				   }
				
			 }
		});
	//############################################ Check the local storage is null or not #################################################################################	
		    if(localStorage.getItem('myWork') != null ){
						 
						    myJob = localStorage.getItem('myWork');
						    myJob =    JSON.parse(myJob);
						
					 }else{
						 alert('No data on localstorage!');
					 }
     //########################################### Set the initial value of slides and slide preview #######################################################################
			 $("#slide_window").append(myJob.mod[0].slides[0].content); //first slide content show
			 $('#courseTitle').html(myJob.courseTitle);  //course title show on the left top hand side of the window
			 $("#SlideTitle").html('slide'+ 0 + 0 ); //first slide index and name show at the bottom of the current slide
			 
			 
			  for(var i=0;i<myJob.mod.length;i++){
					$("#slide_viewer").append('<span><div class="module" data-module="'+ i +'" data-type="module">'+ myJob.mod[i].modTitle +'</div><div class="module'+ i +'body mbody"><div data-type="divider" class="divider"></div></div></span>');
					   for( var j=0;j<myJob.mod[i].slides.length;j++){
					  $('.module'+ i +'body').append('<div class="slides" data-type="slide" data-module-index="'+ i +'"  data-slide-index="'+ j +'">'+ 'slide ' + i +' ' + j /* myJob.mod[i].slides[j].title */ +'</div><div class="divider" data-type="divider"></div>'); 
					 }	  		  
			  }  
			 for(i=0;i<myJob.mod.length;i++){
					if(myJob.mod[i].modState == 'close'){
						$('.module'+ i +'body').hide();
					}else if(myJob.mod[i].modState == 'open'){
						$('.module'+ i +'body').show();
				}
			 }
			 $('.slides').first().addClass('selectedSlide');
			 CurrSlide.mInex = 0;
			 CurrSlide.sInex = 0;
	//############################################ click on slide to show content (save the current changes to local storage) ###############################################
				$(document).on('click','.slides',function(ev){
					 sessionStorage.setItem('IndexSlide', $(this).index('.slides'));
					 saving();
					 $('#showHideGrid').text('Hide Layout');
					 $('.col').css('border','1px dashed #ddd'); 
				   $('.slides').removeClass('selectedSlide');			   
                   $(this).addClass('selectedSlide');
				  
					var  htmlContent  =  $('#slide_window').html();
					var newHtml = htmlContent.replace(/"/g, "'");
					newHtml = newHtml.replace(/(?:\r\n|\r|\n)/g, '');
					myJob.mod[CurrSlide.mInex].slides[CurrSlide.sInex].content = newHtml;	
                    unsave();					 
				    var m  = $(this).attr('data-module-index');
					var s = $(this).attr('data-slide-index');
					CurrSlide.mInex = m;
			        CurrSlide.sInex = s;
				   $("#slide_window").html(myJob.mod[m].slides[s].content);
				   $("#SlideTitle").html('slide'+ m + s );
				
				});
					
	//#####################################################  left click menu ################################################################################################
				 document.getElementById('slide_viewer').addEventListener('contextmenu', function(ev) { 
							ev.preventDefault();
							var mosPsoition = findCursorPosition(ev);
							dataType = ev.target.getAttribute("data-type");
							clickedObjectModule = ev.target.getAttribute("data-module");
							MInedx = ev.target.getAttribute("data-module-index");
							SIndex = ev.target.getAttribute("data-slide-index");
							PrevoiusSlide = $(ev.target).prev('.slides');
							nextSlide = $(ev.target).next('.slides');
							PrevoiusModule = $(ev.target).parent().prev('.module');
							NextModule = $(ev.target).parent().next('.module');
							console.log(dataType)
							showSlideMenu(mosPsoition.x,mosPsoition.y,dataType);
				 }, true);
	//##################################################### click Rename Section ##################################################################################################
	
	             $('#RenameSection').click(function(ev){
					 if(dataType == "module"){
						$('#slide_viewer').find("[data-module='"+ clickedObjectModule +"']").html("<input class='renameEditor' type='text' name='editor'><button id='admitRename' type='button'>ok</button>");
						$(document).on('click','#admitRename',function(ev){
							myJob.mod[parseInt(clickedObjectModule)].modTitle = $('.renameEditor').val();
							localStorage.setItem('myWork', JSON.stringify(myJob));
							$('#slide_viewer').find("[data-module='"+ clickedObjectModule +"']").html(myJob.mod[parseInt(clickedObjectModule)].modTitle);
							unsave();
						});
					 } 
				 });
		 
    //######################################################  click Remove Section ################################################################################################
				$('#RemoveSection').click(function(ev){
					if(dataType == "module"){
					   myJob.mod.splice(clickedObjectModule,1); 
                       jsonReloading(myJob);
                       localStorage.setItem('myWork', JSON.stringify(myJob));	
                       unsave();					   
					}
				});
	//###################################################### click New Slide ################################################################################################
                $('#addNewSlide').click(function(ev){
					
					if(dataType == "slide"){
						 myJob.mod[MInedx].slides.splice(SIndex+1,0,{"content": "<div class='row' style=''><div class='col-md-12 col' style='border: 1px dashed rgb(221, 221, 221);'><h1 class='item centreAlign' data-type='text' data-title='Enter text' data-category='text'>Lorem Ipsum</h1></div></div><div class='row' style=''><div class='col-md-12 col' style='border: 1px dashed rgb(221, 221, 221);'><h2 class='item centreAlign' data-type='text' data-title='Enter text' data-category='text'>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</h2></div></div>",
			            "title": "Slide " + MInedx + " " + parseInt(SIndex) + 1 , "mod": "0"});
						}
					if(dataType == "divider"){
					       var m = $(nextSlide).attr('data-module-index');	
					       var s = $(nextSlide).attr('data-slide-index');	
						   if(m != undefined && s != undefined){
								 myJob.mod[m].slides.splice(s,0,{"content":  "<div class='row' style=''><div class='col-md-12 col' style='border: 1px dashed rgb(221, 221, 221);'><h1 class='item centreAlign' data-type='text' data-title='Enter text' data-category='text'>Lorem Ipsum</h1></div></div><div class='row' style=''><div class='col-md-12 col' style='border: 1px dashed rgb(221, 221, 221);'><h2 class='item centreAlign' data-type='text' data-title='Enter text' data-category='text'>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</h2></div></div>",
								"title": "Slide " + m + " " + parseInt(s) + 1, "mod": "0"});
						    }
							if( m == undefined && s== undefined){
								  m = $(PrevoiusSlide).attr('data-module-index');	
					              s = $(PrevoiusSlide).attr('data-slide-index');
								myJob.mod[m].slides.splice(s+1,0,{"content":  "<div class='row' style=''><div class='col-md-12 col' style='border: 1px dashed rgb(221, 221, 221);'><h1 class='item centreAlign' data-type='text' data-title='Enter text' data-category='text'>Lorem Ipsum</h1></div></div><div class='row' style=''><div class='col-md-12 col' style='border: 1px dashed rgb(221, 221, 221);'><h2 class='item centreAlign' data-type='text' data-title='Enter text' data-category='text'>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</h2></div></div>",
								"title": "Slide " + m + " " + parseInt(s) + 1, "mod": "0"});
							}
						}
                       jsonReloading(myJob);
                       localStorage.setItem('myWork', JSON.stringify(myJob));	
                       unsave();				
					 
				});	
	//#####################################################  Click Delete Slide ################################################################
	             $('#DeleteSlide').click(function(ev){
					if( myJob.mod[MInedx].slides.length == 1){
						alert("You can not delete this slide if you want you can remove section instead!");
					}
					if(dataType == "slide" && myJob.mod[MInedx].slides.length > 1){
						//console.log(dataType+','+MInedx+','+SIndex + ',' + JSON.stringify(myJob.mod[MInedx].slides) );
					   myJob.mod[MInedx].slides.splice(SIndex,1);
                       jsonReloading(myJob);
                       localStorage.setItem('myWork', JSON.stringify(myJob));	
                       unsave();					
					}
				});
		//############################# Click Duplicate Slide ##################################################################################
	             $('#duplicateSlide').click(function(ev){
					
					if(dataType == "slide"){
						myJob.mod[MInedx].slides.splice(parseInt(SIndex) +1,0,myJob.mod[MInedx].slides[SIndex]);
               			 jsonReloading(myJob);
                         localStorage.setItem('myWork', JSON.stringify(myJob));	
                         unsave();		
					}
				});  				
       //####################################### addNewSection #####################################################################################
						 $('#addNewSection').click(function(){
							if(dataType == "viewer"){
									myJob.mod.push({"slides": [{"content" : "<div class='row' style=''><div class='col-md-12 col' style='border: 1px dashed rgb(221, 221, 221);'><h1  class='item centreAlign' data-type='text' data-title='Enter text' data-category='text'>Lorem Ipsum</h1></div></div><div class='row' style=''><div class='col-md-12 col' style='border: 1px dashed rgb(221, 221, 221);'><h2 class='item centreAlign' data-type='text' data-title='Enter text' data-category='text'>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</h2></div></div>","title": "Slide 34","mod": "11"}],"modTitle": "ThisNew","modState": "open"});
									 jsonReloading(myJob);
                                     localStorage.setItem('myWork', JSON.stringify(myJob));	
                                     unsave();	
							}
							if(dataType == "divider"){
								 var m = $(nextSlide).attr('data-module-index');	
					             var s = $(nextSlide).attr('data-slide-index');
								 if( m != undefined && s != undefined){
									if(myJob.mod[m].slides.length == 0 || s == 0){
										alert("You can not add more section here!");
									}									
									else if(myJob.mod[m].slides.length > 0){
											 var slicedArray = myJob.mod[m].slides.splice(s);
											 myJob.mod.splice(parseInt(m)+1,0,{"slides": slicedArray,"modTitle": "AddInsert","modState": "open"});
									}
								 }
								 if(m == undefined && s == undefined){

					 				 m = $(PrevoiusSlide).attr('data-module-index');	
					                 s = $(PrevoiusSlide).attr('data-slide-index');
									 myJob.mod.splice(parseInt(m)+1,0,{"slides": [{"content" : "<div class='row' style=''><div class='col-md-12 col' style='border: 1px dashed rgb(221, 221, 221);'><h1 class='item centreAlign' data-type='text' data-title='Enter text' data-category='text'>Lorem Ipsum</h1></div></div><div class='row' style=''><div class='col-md-12 col' style='border: 1px dashed rgb(221, 221, 221);'><h2 class='item centreAlign' data-type='text' data-title='Enter text' data-category='text'>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</h2></div></div>","title": "Slide 35","mod": "11"}],"modTitle": "ThisNew","modState": "open"}); 
								 }
								 jsonReloading(myJob);
								 localStorage.setItem('myWork', JSON.stringify(myJob));	
								 unsave();
							}
		
						 });//end of click addd new section between slides and modules 
//#################################################################  Click Add Section 	 #################################################################
						 $('#addSection').click(function(ev){
								if(dataType == "slide"){
									//console.log(dataType+','+MInedx+','+SIndex + ',' + JSON.stringify(myJob.mod[MInedx].slides));
									if(myJob.mod[MInedx].slides.length == 1 || SIndex == 0){	
										alert("You can not add more section here!");
									}
									if(myJob.mod[MInedx].slides.length > 1 && SIndex != 0){
									   var slicedArray = myJob.mod[MInedx].slides.splice(SIndex);	
									   myJob.mod.splice(parseInt(MInedx)+1,0,{"slides": slicedArray,"modTitle": "newSection","modState": "open"});
									}
							    }
					             jsonReloading(myJob);
								 localStorage.setItem('myWork', JSON.stringify(myJob));	
								 unsave();   
						});  		

       //################################################################# slider slide animation #################################################################
		$(document).on('click','.module',function(ev){
		    console.log(ev.target.getAttribute("data-module"));
		  var Mod = ev.target.getAttribute("data-module");
		     parseInt(Mod);
		    if(myJob.mod[Mod].modState == "close"){
				myJob.mod[Mod].modState = "open";
				$('.module'+ Mod +'body').slideDown();
			}else if(myJob.mod[Mod].modState == "open"){
				myJob.mod[Mod].modState = "close";
				$('.module'+ Mod +'body').slideUp();
			}
			localStorage.setItem('myWork', JSON.stringify(myJob));
			unsave();   
		 });						
		 
		 
		
	//#################################################################  Reload json without refreshing page  #################################################################

 	function jsonReloading(){

				 $("#slide_window").html(myJob.mod[0].slides[0].content);
				 $("#SlideTitle").html(myJob.mod[0].slides[0].title);
				 $('#courseTitle').html(myJob.courseTitle);
				  $('#slide_viewer').html('');
				  for(var i=0;i<myJob.mod.length;i++){
					$("#slide_viewer").append('<span><div class="module" data-module="'+ i +'" data-type="module">'+ myJob.mod[i].modTitle +'</div><div class="module'+ i +'body mbody"><div data-type="divider" class="divider"></div></div></span>');
					   for( var j=0;j<myJob.mod[i].slides.length;j++){
					  $('.module'+ i +'body').append('<div class="slides" data-type="slide" data-module-index="'+ i +'"  data-slide-index="'+ j +'">'+ 'slide ' + i + ' ' + j /* myJob.mod[i].slides[j].title */ +'</div><div class="divider" data-type="divider"></div>'); 
					 }	  		  
				  }
				  for(var i=0;i<myJob.mod.length;i++){
												//alert(data.mod[i].modState); 
												if(myJob.mod[i].modState == 'close'){
													$('.module'+ i +'body').hide();
												}else if(myJob.mod[i].modState == 'open'){
													$('.module'+ i +'body').show();
												}
											 } 
				  $('#slide_viewer').scrollTop(ViewerScroll);		  
			  }
			  
			
	

	//################################################################# Load json data #################################################################
	$('#Uploadfile').click(function(){
		
	
		
	});
	//################################################################ Edit course title #########################################################################
	$('#courseTitle').hover(
	function(){
		//$('#editcourseTitle').css('visibility','visible');
	},function(){
		//$('#editcourseTitle').css('visibility','hidden');
	} );
	$('#applytitle').click(function(){
		 myJob.courseTitle = $('#txtEdit').val();
		 $('#courseTitle').text(myJob.courseTitle);
		 $('#titleSuccess').show();
		 unsave();
	});
	$('#closeEdit').click(function(){
		$('#titleSuccess').hide();
	});	
	
//################################################################# sortable function #################################################################


});


//################################################################# left click customize menu #################################################################
function showSlideMenu(x,y,dType){
			document.getElementById('SlideMenu').style.top = y + 'px';
			document.getElementById('SlideMenu').style.left = x + 'px';
			customizeSlideMenu(dataType);
			$('#SlideMenu').show();
	}
function findCursorPosition(event){
			var currentMousePos = { x: -1, y: -1 };
			currentMousePos.x = event.clientX;
			currentMousePos.y = event.clientY;
			return currentMousePos;
	}
//Customizing data type menu based on its position and data type target
function customizeSlideMenu(dataType){

if(dataType == "slide"){
		$("#SlideMenu").find('li:eq(0),li:eq(1),li:eq(2),li:eq(3)').show();
	   $("#SlideMenu").find('li:eq(4),li:eq(5),li:eq(6)').hide();
 }else if (dataType == "module" ){
		$("#SlideMenu").find('li:eq(0),li:eq(1),li:eq(2),li:eq(3),li:eq(4)').hide();
		$("#SlideMenu").find('li:eq(5),li:eq(6)').show();
  }else if(dataType == "divider"){
		$("#SlideMenu").find('li:eq(1),li:eq(2),li:eq(3),li:eq(5),li:eq(6)').hide();
		$("#SlideMenu").find('li:eq(0),li:eq(4)').show();
    }
	else{
		$("#SlideMenu").find('li:eq(0),li:eq(1),li:eq(2),li:eq(3),li:eq(5),li:eq(6)').hide();
		$("#SlideMenu").find('li:eq(4)').show();
	}
}

$('#btnSave').click( function(){
	 saving();
	localStorage.setItem('myWork', JSON.stringify(myJob));	
	data  = localStorage.getItem('myWork');
	if($('#btnSave').hasClass('unsave')){
		$.ajax({
			type: "POST",
			dataType: "json",
			url: "/ajax/saveData/",
			data: data,
			success: function(data){
			alert('You\'re Data is saved successfully');
			$('#btnSave').removeClass('unsave');
			//location.reload();
			},
			error: function(e){		
			}
		});  
		
	}else{
		return false;
	}
});

function unsave() {
    unsave.called = true;
	$('#btnSave').addClass('unsave');   
}
$(document).click(function(){
 $("#SlideMenu").hide();
});
//################################################################# function check page reload or refresh #################################################################
   window.onbeforeunload = function(event)
    {
		if($('#btnSave').hasClass('unsave')){
        return confirm("Confirm refresh");
		}else{
			$('#btnSave').removeClass('unsave');
			
			location.reload();
		}
    };
//################################################################# Add cookie and crftoken for django forms #################################################################
function getCookie(name) {
    var cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        var cookies = document.cookie.split(';');
        for (var i = 0; i < cookies.length; i++) {
            var cookie = jQuery.trim(cookies[i]);
            // Does this cookie string begin with the name we want?
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}
var csrftoken = getCookie('csrftoken');
function csrfSafeMethod(method) {
    // these HTTP methods do not require CSRF protection
    return (/^(GET|HEAD|OPTIONS|TRACE)$/.test(method));
}
$.ajaxSetup({
    beforeSend: function(xhr, settings) {
        if (!csrfSafeMethod(settings.type) && !this.crossDomain) {
            xhr.setRequestHeader("X-CSRFToken", csrftoken);
        }
    }
}); 
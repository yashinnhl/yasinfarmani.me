import json
import datetime
from django.http import Http404, HttpResponse
from django.views.decorators.csrf import csrf_exempt
from django.core.files.storage import FileSystemStorage
from SaitamaApp2.forms import UploadFileForm




def loadJson(request):
    if  request.POST:
        form = UploadFileForm(request.POST, request.FILES)
        print('recieveeeeeeeeeeeeeeeeeee....' + str(handle_uploaded_file(request.FILES['jsonFile'])))       
        #my_uploaded_file = request.FILES['my_uploaded_file'].read()
        #print('recieveeeeeeeeeeeeeeeeeee....' + my_uploaded_file) 
        #data = json.loads(request.body)
          
        #writeInFileData(data)
        return HttpResponse('uploaded'+str(form))
    else:
        raise Http404

def handle_uploaded_file(f):
    with open('some/file/name.txt', 'wb+') as destination:
        for chunk in f.chunks():
            destination.write(chunk)

			
			
def saveData(request):
    if request.is_ajax() and request.POST:
        data = json.loads(request.body)
        print('recieved' + json.dumps(data))
        writeInFileData(data)
        return HttpResponse(json.dumps(data), content_type='application/json')
    else:
        raise Http404

		
		
		
def writeInFileData(data):
    with open('static/data/coursedata2.json', 'w') as outfile:
            json.dump(data, outfile)